Here is a guide to set up a sample project.

Download this legally available ROM: http://ludumdare.com/compo/2014/06/23/creating-my-first-nes-game/

Make a new project with that as the source ROM

Make a new assembly source and paste this in:

.org $1A8
NOP
NOP

You can discover through the FCEUX memory viewer where the lives are in RAM, and use its debugger to find the code that subtracts a life when you're hit and where that code is in the ROM. This code replaces the subtraction code with no-ops. You can also set the PC to its appropriate value with * = $<number> for use in jump instructions.